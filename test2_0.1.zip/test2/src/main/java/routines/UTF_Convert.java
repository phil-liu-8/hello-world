package routines;
import java.io.UnsupportedEncodingException;
import java.util.List;

public class UTF_Convert {

    public static String convertISOtoUTF(String source_string) throws UnsupportedEncodingException  {
       String output_row = null;
        if (source_string == null) {
             source_string = null; //$NON-NLS-1$
        }
        else {
             String iso = new String(source_string.getBytes("ISO-8859-1"), "UTF-8");
             String resultString = iso.replaceAll("[^\\x00-\\x7F]", "_");
             //resultString = resultString.replaceAll(",", ".");
            /* Integer cut = 255;
             if (resultString.length()>cut)
             resultString = resultString.substring(0, cut);*/
             output_row=resultString;
             }
        return output_row;
    }
}
