

package routines;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class CernerConverter {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
public static boolean isInteger(String value){
String sNum = value.replaceAll("[^0-9.-]","");
if (value.equals(sNum) && !sNum.contains(".")){
return true;
}
else
return false;
 
}

public static boolean isFloat(String value){
String sNum = value.replaceAll("[^0-9.-]","");
if (value.equals(sNum) && sNum.contains(".")){
return true;
}
else
return false;
}

public static boolean isFloatWithUnit(String value){
String sNum = value.replaceAll("[^0-9.-]","");
if (value.equals(sNum + " lbs") ||
value.equals(sNum + "  lbs")
 

){
return true;
}
else
return false;
}

    public static String makeNumeric(String value) {
        if (value == null) {
            return null;
        }
String sNum = value.replaceAll("[^0-9.-]","").replaceAll("-$","");
if (!sNum.isEmpty() && sNum.length()>1){
//System.out.println("Trying to find -");
String sign = sNum.substring(0, 1);
String remain = sNum.substring(1);

//System.out.println("Sign is: '" + sign + "'");
//System.out.println("remain is: '" + remain + "'");

int sPos = remain.indexOf("-");
Integer dPos = sPos;

//System.out.println("sPos is: " + dPos.toString());
int tPos = sPos;
Integer tdPos = tPos;
//System.out.println("tPos is: " + dPos.toString());

if (sPos==0) sNum = sign;
else {
if (sPos>=0) sNum = sign + remain.substring(0,tPos);
}
sNum = sNum.replaceAll("-", "");
if (sign.equals("-")) sNum = sign + sNum;
}
return sNum;
    }
    
    public static Integer makeInteger(String value){
    System.out.println("MakeInterger from:(" + value + ")");
    Integer result = null;
    String sNum = makeNumeric(value);
    if (sNum.isEmpty()){
    
System.out.println("MakeInteger result:(NULL)");
        
return null;
    }
    try {
    Float f = Float.parseFloat(sNum);
     
    result = f.intValue();
    }
    catch (Exception ex){
    
System.err.println("WARNING: error parsing numeric value from '" + sNum +"' returing null instead");
    
return null;
    }
    System.out.println("MakeInteger result:(" + result.toString() + ")");
    return result;
    }
}
