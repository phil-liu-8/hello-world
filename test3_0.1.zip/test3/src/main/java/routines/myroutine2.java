package routines;
import java.util.Date;
import java.util.Calendar;
public class myroutine2 {
    static java.util.Calendar cal = java.util.Calendar.getInstance();
    public static Date convertLocaltoUTCTime(Date date) {
        cal.setTime(date);
        cal.add(java.util.Calendar.HOUR_OF_DAY, +8);
        cal.add(java.util.Calendar.MINUTE, +0);
        return cal.getTime();
    }
}