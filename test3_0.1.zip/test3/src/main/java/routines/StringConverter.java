package routines;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;


/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class StringConverter {
	
	public static boolean isNumeric(String str)  
	{  
	  try  
	  {  
	    double d = Double.parseDouble(str);  
	    doubleValue = d;
	  }  
	  catch(NumberFormatException nfe)  
	  {  
	    return false;  
	  }  
	  return true;  
	}
	
	private static List<String>tokens;
	
	public static Integer getTokenCount(String str){
		// used to check if there are more then 2 tokens, this indicates that this is a text
		StringTokenizer st = new StringTokenizer(str);

		Integer tokenCount = 0;
		
		tokens = new ArrayList<String>();
		
		// System.out.println("---- Split by space ------");
		while (st.hasMoreElements()) {
			String theToken = (String)st.nextElement();
			tokens.add(theToken);
			tokenCount++;
		}
		
		return tokenCount;

	}
	
	private static String unit = null;
	
	public static void parseValue(String str){
		unit = null;
		doubleValue = null;
		
		Integer tokenCount = getTokenCount(str);
		if (tokenCount<=1){
			if (isNumeric(str)){
				valueType = "NUMERIC";
			}
			else {
				valueType = "STRING";
			}
		} else if (tokenCount==2){
			if (isNumeric(tokens.get(0))){
				valueType = "QUANTITY";
				unit = tokens.get(1);
			}
		} else valueType ="STRING";
	}

	private static Double doubleValue = null;
	
	private static String valueType = null;
		// STRING
		// NUMERIC
		// QUANTITY
	
	public static String getValueType(){
		return valueType;
	}
	
	public static Double getDouble(){
		return doubleValue;
	}
	
	public static String getUnit(){
		return unit;
	}
	
	public String getType(){
		return valueType;
	}

	public static Boolean typeIsNumeric(){
		return valueType.equals("NUMERIC");
	}
	
	public static Boolean typeIsQuantity(){
		return valueType.equals("QUANTITY");
	}
	

}
