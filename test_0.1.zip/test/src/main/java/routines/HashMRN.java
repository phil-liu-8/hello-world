package routines;
import java.util.List;

import com.sagence.*;
import com.sagence.talendutils.AdminUtil;
import com.sagence.talendutils.PhiUtil;

/*
 * user specification: the function's comment should contain keys as follows: 1. write about the function's comment.but
 * it must be before the "{talendTypes}" key.
 * 
 * 2. {talendTypes} 's value must be talend Type, it is required . its value should be one of: String, char | Character,
 * long | Long, int | Integer, boolean | Boolean, byte | Byte, Date, double | Double, float | Float, Object, short |
 * Short
 * 
 * 3. {Category} define a category for the Function. it is required. its value is user-defined .
 * 
 * 4. {param} 's format is: {param} <type>[(<default value or closed list values>)] <name>[ : <comment>]
 * 
 * <type> 's value should be one of: string, int, list, double, object, boolean, long, char, date. <name>'s value is the
 * Function's parameter name. the {param} is optional. so if you the Function without the parameters. the {param} don't
 * added. you can have many parameters for the Function.
 * 
 * 5. {example} gives a example for the Function. it is optional.
 */
public class HashMRN {

    /**
     * helloExample: not return value, only print "hello" + message.
     * 
     * 
     * {talendTypes} String
     * 
     * {Category} User Defined
     * 
     * {param} string("world") input: The string need to be printed.
     * 
     * {example} helloExemple("world") # hello world !.
     */
    public static String convertMRNtoHash(String mrn) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
            mrn = ""; //$NON-NLS-1$
        }
        return pu.convertMRNtoHash(mrn); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String convertFINtoHash(String fin) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (fin == null) {
            fin = ""; //$NON-NLS-1$
        }
        return pu.convertFINtoHash(fin); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static List<String> getAllMRNtoHash(String mrn) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
            mrn = ""; //$NON-NLS-1$
        }
        return pu.getAllMRNtoHash(mrn); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String decryptID(String id, String phrase) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (id == null) {
            id = ""; //$NON-NLS-1$
        }
        return pu.decryptID(id, phrase); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String encryptID(String id, String phrase) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (id == null) {
            id = ""; //$NON-NLS-1$
        }
        return pu.encryptID(id, phrase); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String encryptDOB(String mrn, String dob) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
        	mrn = ""; //$NON-NLS-1$
        }
        return pu.getDOB(mrn, dob); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String getPersonFirstName(String mrn) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
        	mrn = ""; //$NON-NLS-1$
        }
        return pu.getPersonFirstName(mrn); //$NON-NLS-1$ //$NON-NLS-2$
    }

    public static String getPersonLastName(String mrn) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
        	mrn = ""; //$NON-NLS-1$
        }
        return pu.getPersonLastName(mrn); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
    public static String getPersonName(String mrn) {
    	// AdminUtil au = new AdminUtil();
    	PhiUtil pu = new PhiUtil();
    	
        if (mrn == null) {
        	mrn = ""; //$NON-NLS-1$
        }
        return pu.getPersonName(mrn); //$NON-NLS-1$ //$NON-NLS-2$
    }
    
}
